from __future__ import annotations

import warnings

from .protocol import SEND_EOF, Protocol as Connection, Side, State  # noqa: F401


warnings.warn(
    "websockets.connection was renamed to websockets.protocol "
    "and Connection was renamed to Protocol",
    DeprecationWarning,
)
